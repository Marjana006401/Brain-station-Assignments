
public class Students {
		   private int id;
		   private String fname;
		   private double cgpa;
		   public  Students(int id, String fname, double cgpa) {
		      super();
		      this.id = id;
		      this.fname = fname;
		      this.cgpa = cgpa;
		   }
		   public int getId() {
		      return id;
		      
		   }
		   public String getFname() {
			      return fname;
		   }
		   public double getCgpa() {
			      return cgpa;
		   }
}


