import java.util.*;

public class Main {

	
	   public static void main(String[] args){
	      Scanner in = new Scanner(System.in);
	      int tests = Integer.parseInt(in.nextLine());
	      
	      List<Students> studentList = new ArrayList<Students>();
	      while(tests>0){
	         int id = in.nextInt();
	         String fname = in.next();
	         double cgpa = in.nextDouble();
	         
	         Students st = new Students(id, fname, cgpa);
	         studentList.add(st);
	         
	         tests--;
	      }
	      Collections.sort(studentList,  Comparator.comparing(Students :: getCgpa).reversed().thenComparing(Students :: getFname).thenComparing(Students :: getId));
	         for(Students st: studentList){
	         System.out.println(st.getFname());
	      }
	   }

}
