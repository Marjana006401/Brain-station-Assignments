package Tasks1.BrainStation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class BuyProducts {
    static WebDriver driver ;
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user012\\eclipse-workspace\\EvalyTask\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		
		driver.get("http://automationpractice.com/index.php");
		
		driver.manage().window().maximize();
		Thread.sleep(2000);
		try {
			WebElement signUp = driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")); // enter into sign up page
		    driver.get(signUp.getAttribute("href"));
		    
		    WebElement emailInput =driver.findElement(By.id("email_create")); // Entering email
		    emailInput.click();
		    emailInput.sendKeys("tisha3.akter@gmail.com");
		 
		    WebElement createAcc =driver.findElement(By.xpath("//*[@id=\"SubmitCreate\"]")); //go to sign up form clicking create acc
		    createAcc.click();
		    
		    Thread.sleep(3000);
		    WebElement chooseGender =driver.findElement(By.id("id_gender2")); // Choosing gender
		    chooseGender.click();
		    
		    WebElement firstName =driver.findElement(By.id("customer_firstname")); // sending firstname
		    firstName.click();
		    firstName.sendKeys("Shamima");
		    
		    WebElement lastName =driver.findElement(By.id("customer_lastname")); // sending lastname
		    lastName.click();
		    lastName.sendKeys("Bithi");
		    
		    WebElement password =driver.findElement(By.id("passwd")); // sending password
		    password.click();
		    password.sendKeys("000000006401");
		    
		    Thread.sleep(2000);
		    Select daysDropdown =new Select (driver.findElement(By.xpath("//*[@id=\"days\"]"))); // selecting days
		    daysDropdown.selectByIndex(2);
		    Thread.sleep(1000);
		    Select monthsDropdown =new Select (driver.findElement(By.xpath("//*[@id=\"months\"]"))); // selecting days
		    monthsDropdown.selectByVisibleText("December ");
		    Thread.sleep(1000);
		    Select yearsDropdown =new Select (driver.findElement(By.xpath("//*[@id=\"years\"]"))); // selecting days
		    yearsDropdown.selectByIndex(20);
		    
		    WebElement checkBox =driver.findElement(By.xpath("//*[@id=\"newsletter\"]")); // checkbox
		    checkBox.click();
		    
		 
		    WebElement company =driver.findElement(By.xpath("//*[@id=\"company\"]")); // sending company
		    company.click();
		    company.sendKeys("naztech");
		    
		    WebElement address1 =driver.findElement(By.xpath("//*[@id=\"address1\"]")); // sending address1
		    address1.click();
		    address1.sendKeys("01216");
		    
		    WebElement address2 =driver.findElement(By.xpath("//*[@id=\"address2\"]")); // sending address2
		    address2.click();
		    address2.sendKeys("5A");
		    WebElement city =driver.findElement(By.xpath("//*[@id=\"city\"]")); // sending city
		    city.click();
		    city.sendKeys("Dhaka");
		    Thread.sleep(2000);
		    Select stateDropdown =new Select (driver.findElement(By.xpath("//*[@id=\"id_state\"]"))); // selecting state
		    stateDropdown.selectByIndex(1);
		    WebElement postalCode =driver.findElement(By.xpath("//*[@id=\"postcode\"]")); // sending postal code
		    postalCode.click();
		    postalCode.sendKeys("01216");
		    Thread.sleep(2000);
		    Select countryDropdown =new Select (driver.findElement(By.xpath("//*[@id=\"id_country\"]"))); // selecting country
		    countryDropdown.selectByIndex(1);
		    
		    WebElement additionalInformation =driver.findElement(By.xpath("//*[@id=\"other\"]")); // sending other
		    additionalInformation.click();
		    additionalInformation.sendKeys("01216");
		    WebElement phonNumber1 =driver.findElement(By.xpath("//*[@id=\"phone\"]")); // sending Phone_Num1
		    phonNumber1.click();
		    phonNumber1.sendKeys("01785814665");
		    WebElement phonNumber2 =driver.findElement(By.xpath("//*[@id=\"phone_mobile\"]")); // sending Phone_Num2
		    phonNumber2.click();
		    phonNumber2.sendKeys("01785814665");
		    WebElement referenceAddress =driver.findElement(By.xpath("//*[@id=\"alias\"]")); // sending Phone_Num2
		    referenceAddress.click();
		    referenceAddress.clear();
		    referenceAddress.sendKeys("01785814665");
		    WebElement registerButton =driver.findElement(By.xpath("//*[@id=\"submitAccount\"]")); // click to register
		    registerButton.click();
			
		    WebElement navWomen = driver.findElement(By.xpath("//*[@id=\"block_top_menu\"]/ul/li[1]/a")); // women product
		    driver.get(navWomen.getAttribute("href"));
		    
		    WebElement addToCart = driver.findElement(By.xpath("//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/div[2]/a[1]")); // add to cart
		    driver.get(addToCart.getAttribute("href"));
		    WebElement proceed1 = driver.findElement(By.xpath("//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/a")); // proceed 
		    driver.get(proceed1.getAttribute("href"));
		    WebElement proceed2 = driver.findElement(By.xpath("//*[@id=\"center_column\"]/p[2]/a[1]")); // proceed 
		    driver.get(proceed2.getAttribute("href"));
		    WebElement proceed3 =driver.findElement(By.xpath("//*[@id=\"center_column\"]/form/p/button")); // proceed
		    proceed3.click();
		    WebElement checkedToConfirm =driver.findElement(By.xpath("//*[@id=\"cgv\"]")); // confirm
		    checkedToConfirm.click();
		    WebElement proceed4 =driver.findElement(By.xpath("//*[@id=\"form\"]/p/button")); // proceed
		    proceed4.click();
		    
		    WebElement payment = driver.findElement(By.xpath("//*[@id=\"HOOK_PAYMENT\"]/div[2]/div/p/a")); // payment 
		    driver.get(payment.getAttribute("href"));
		    
		    WebElement confirmedOrder = driver.findElement(By.xpath("//*[@id=\"cart_navigation\"]/button")); // confirmedOrder 
		    confirmedOrder.click();
		} catch (Exception e) {
			System.out.println(e);
		}
		 driver.close();
	
		
	}
	
	

}
